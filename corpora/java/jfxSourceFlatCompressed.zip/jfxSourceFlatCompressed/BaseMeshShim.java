package com.sun.prism.impl;
public class BaseMeshShim {
public static boolean test_isVertexBufferNull(BaseMesh mesh) {
return mesh.test_isVertexBufferNull();
}
public static int test_getVertexBufferLength(BaseMesh mesh) {
return mesh.test_getVertexBufferLength();
}
public static int test_getNumberOfVertices(BaseMesh mesh) {
return mesh.test_getNumberOfVertices();
}
}
