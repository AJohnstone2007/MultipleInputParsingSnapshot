package com.sun.javafx.font.coretext;
class CGRect {
CGPoint origin = new CGPoint();
CGSize size = new CGSize();
}
