package com.sun.javafx.image;
public interface BytePixelAccessor
extends BytePixelGetter, BytePixelSetter
{
}
