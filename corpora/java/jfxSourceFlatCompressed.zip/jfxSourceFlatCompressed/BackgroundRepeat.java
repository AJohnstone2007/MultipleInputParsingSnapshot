package javafx.scene.layout;
public enum BackgroundRepeat {
REPEAT,
SPACE,
ROUND,
NO_REPEAT
}
