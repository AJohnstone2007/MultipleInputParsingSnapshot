package com.sun.javafx.font.coretext;
class CGPoint {
double x;
double y;
}
