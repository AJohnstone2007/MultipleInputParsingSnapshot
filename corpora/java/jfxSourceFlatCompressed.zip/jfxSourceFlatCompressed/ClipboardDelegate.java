package com.sun.glass.ui.delegate;
import com.sun.glass.ui.Clipboard;
public interface ClipboardDelegate {
public Clipboard createClipboard(String clipboardName);
}
