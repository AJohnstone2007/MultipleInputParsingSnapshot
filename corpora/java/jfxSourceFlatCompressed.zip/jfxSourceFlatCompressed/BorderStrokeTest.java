package test.javafx.scene.layout;
import org.junit.Test;
public class BorderStrokeTest {
@Test public void dummy() { }
}
