package javafx.util;
@FunctionalInterface
public interface Builder<T> {
public T build();
}
