package javafx.scene.shape;
public enum ArcType {
OPEN,
CHORD,
ROUND
}
