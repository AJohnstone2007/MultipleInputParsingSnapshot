package test.com.sun.javafx.scene.control.behavior;
import org.junit.Test;
public class AccordionBehaviorTest {
@Test public void focusGainedIsCaughtByBehavior() {
}
}
