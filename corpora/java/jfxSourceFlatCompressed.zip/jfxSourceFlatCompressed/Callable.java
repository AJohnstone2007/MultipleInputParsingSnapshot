package test.javafx.collections;
public interface Callable<V> {
V call() throws Exception;
}
