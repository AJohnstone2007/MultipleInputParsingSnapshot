package com.sun.javafx.image;
public enum AlphaType {
OPAQUE,
PREMULTIPLIED,
NONPREMULTIPLIED
}
