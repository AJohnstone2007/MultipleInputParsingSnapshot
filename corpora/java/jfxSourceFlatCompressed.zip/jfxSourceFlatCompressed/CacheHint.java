package javafx.scene;
public enum CacheHint {
DEFAULT,
SPEED,
QUALITY,
SCALE,
ROTATE,
SCALE_AND_ROTATE,
}
