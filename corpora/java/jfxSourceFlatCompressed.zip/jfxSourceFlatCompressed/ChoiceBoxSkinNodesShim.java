package javafx.scene.control.skin;
import javafx.scene.control.ContextMenu;
public class ChoiceBoxSkinNodesShim {
public static String getChoiceBoxSelectedText(ChoiceBoxSkin skin) {
return skin.getChoiceBoxSelectedText();
}
public static ContextMenu getChoiceBoxPopup(ChoiceBoxSkin skin) {
return skin.getChoiceBoxPopup();
}
}
