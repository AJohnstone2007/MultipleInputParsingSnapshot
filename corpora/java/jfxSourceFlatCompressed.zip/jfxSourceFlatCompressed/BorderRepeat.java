package javafx.scene.layout;
public enum BorderRepeat {
STRETCH,
REPEAT,
ROUND,
SPACE
}
