package com.sun.javafx.geom.transform;
import com.sun.javafx.geom.Vec3d;
public interface CanTransformVec3d {
public Vec3d transform(Vec3d point, Vec3d pointOut);
}
