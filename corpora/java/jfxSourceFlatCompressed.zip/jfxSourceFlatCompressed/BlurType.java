package javafx.scene.effect;
public enum BlurType {
ONE_PASS_BOX,
TWO_PASS_BOX,
THREE_PASS_BOX,
GAUSSIAN,
}
