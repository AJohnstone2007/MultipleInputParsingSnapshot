package test.com.sun.javafx.scene.layout.region;
import org.junit.Test;
public class BackgroundFillConverterTest {
@Test public void dummy() { }
}
