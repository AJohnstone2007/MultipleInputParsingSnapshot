package com.sun.javafx.font.coretext;
class CGSize {
double width;
double height;
}
