package test.javafx.fxml;
public enum Alignment {
LEFT,
RIGHT,
CENTER
}
