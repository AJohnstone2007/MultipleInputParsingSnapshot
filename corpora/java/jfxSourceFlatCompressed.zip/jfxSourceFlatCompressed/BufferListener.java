package com.sun.media.jfxmedia.events;
public interface BufferListener {
public void onBufferProgress(BufferProgressEvent evt);
}
